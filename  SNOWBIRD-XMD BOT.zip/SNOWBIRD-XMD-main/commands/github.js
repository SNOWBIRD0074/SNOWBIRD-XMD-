async function githubCommand(sock, chatId) {
    const repoInfo = `*🤖 SNOWBIRD XMD*

*📂 GitHub Repository:*
https://github.com/SNOWBIRD0074/SNOWBIRD-XMD-

*📢 MAIN CHANNEL:*
https://whatsapp.com/channel/0029Vb5nSebFy722d2NEeU3C

_STAR💥 AND FORK THE REPO IF U LIKE💋 SNOWBIRD-XMD BOT🇿🇼!_`;

    try {
        await sock.sendMessage(chatId, {
            text: repoInfo,
            contextInfo: {
                forwardingScore: 1,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '120363420227773494@newsletter',
                    newsletterName: 'SNOWBIRD-XMD',
                    serverMessageId: -1
                }
            }
        });
    } catch (error) {
        console.error('Error in github command:', error);
        await sock.sendMessage(chatId, { 
            text: '❌ Error fetching repository information.' 
        });
    }
}

module.exports = githubCommand; 