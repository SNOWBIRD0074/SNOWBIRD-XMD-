const settings = {
  packname: 'SNOWBIRD',
  author: '‎',
  botName: "SNOWBIRD-XMD",
  botOwner: 'SNOWBIRD', // Your name
  ownerNumber: '263710407389', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "1.0.0",
};

module.exports = settings;
